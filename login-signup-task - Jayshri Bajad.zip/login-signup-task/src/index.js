const express = require('express');
const app = express();
const path = require('path');
const hbs = require('hbs');
const collection = require('./mongodb');

const templatePath = path.join(__dirname, '../templates');

app.use(express.json());
app.set('view engine', 'hbs');
app.set('views', templatePath);
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, '../public')));

// Existing routes
app.get('/', (req, res) => {
    res.render('login');
});

app.get('/signup', (req, res) => {
    res.render('signup', { errorMessage: null, successMessage: null });
});

app.post('/signup', async (req, res) => {
    try {
        const { name, email, mobile, password } = req.body;
        const existingUser = await collection.findOne({
            $or: [{ email: email }, { mobile: mobile }]
        });
        if (existingUser) {
            res.render('signup', { errorMessage: 'Account with this email or mobile number already exists', successMessage: null });
        } else {
            const data = { name, email, mobile, password };
            await collection.insertMany([data]);
            res.render('signup',{ errorMessage: null, successMessage: 'Congratulations your account is created ! Please login' });
        }
    } catch (error) {
        res.render('signup', { errorMessage: 'An error occurred during signup', successMessage: null });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { login, password } = req.body;
        const user = await collection.findOne({
            $or: [{ email: login }, { mobile: login }]
        });
        if (!user) {
            res.render('login', { message: 'Wrong email or mobile number' });
        } else if (user.password !== password) {
            res.render('login', { message: 'Wrong password' });
        } else {
            res.render('home');
        }
    } catch (error) {
        res.render('login', { message: 'Error logging in' });
    }
});

// New forgotten account route
app.get('/forgotten-account', (req, res) => {
    res.render('forgotten-account');
});

app.post('/forgotten-account', async (req, res) => {
    try {
        const { login } = req.body;
        const user = await collection.findOne({
            $or: [{ email: login }, { mobile: login }]
        });

        if (!user) {
            // User not found
            res.render('forgotten-account', { message: 'No account found with this email or mobile number' });
        } else {
            // Logic to send password reset link or verification code via email or SMS
            // This example just renders a message
            res.render('forgotten-account', { message: 'Password reset link sent. Check your email or SMS' });
        }
    } catch (error) {
        res.render('forgotten-account', { message: 'Error processing request' });
    }
});


app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
